# No Delay Mod — Minecraft 1.21.11

Fabric client-side port of the original No Delay Optimizer.

Target:
- Minecraft 1.21.11
- Fabric Loader 0.19.2+
- Fabric API 0.141.3+1.21.11
- Java 21
- Yarn 1.21.11+build.6

Build with Gradle 9.5.1:
`gradle build`

The resulting JAR is in `build/libs/`.
